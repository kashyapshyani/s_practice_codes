from pages.base_page import BasePage


class SignUpBasePage(BasePage):
    pass
